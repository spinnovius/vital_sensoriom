@extends('layouts.admin_main')
@section('content')
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <div class="row">
                    <!-- column -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h3>All Patient's Data</h3>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>NAME</th>
                                                <th>AGE</th>
                                                <th>SEX</th>
                                                <th>PHONE NUMBER</th>
                                                <th>EMAIL</th>
                                                <th>ACTION</th>
                                            </tr>
                                        </thead>
                                        <tbody>

            <?php
			foreach ($PatientDetail as $e) { ?>
				
			<tr>
				
				<td><?php echo $e->fname; ?></td>
				<td><?php echo $e->dob; ?></td>
				<td><?php echo $e->gender; ?></td>
				<td><?php echo $e->contact_number; ?></td>
				<td><?php echo $e->email; ?></td>
				<td class="center">
                    <a href="" class="btn btn-info btn-xs pull-left"><i class="fa fa-edit"></i></a> 
					<a href="" class="btn btn-danger btn-xs pull-left" style="margin-left: 5%;margin-top: -2px;""><i class="fa fa-trash"></i></a>
 				</td>                                              
			</tr>
			<?php 
				} 
			?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
@endsection