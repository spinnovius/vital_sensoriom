@extends('layouts.admin_main')
@section('content')

<section class="content-header">
    <h1>
        Dashboard asdasd
<!--        <small>Control panel</small>-->
    </h1>

    </section>

@endsection
