@extends('layouts.admin_main')
@section('content')

<section class="content-header">
    <h3 style="margin-left: 30px;">ADD DOCTOR</h3>
    <!--  <input type="text" placeholder="Search.." name="search">
     <button type="submit"><i class="fa fa-search"></i></button> -->
</section>
<div class="col-sm-10">
<div class="container">
<form method="post" action="{{ route('admin_main.store_doctor') }}">
    {!! csrf_field() !!}
  
  <div class="form-row">
    <!-- <div class="col-md-6 mb-3">
      <input type="text" class="form-control" id="validationDefault01" placeholder="CITY"  required>
    </div> -->
    <div class="form-group">
        <!-- <label class="control-label">Select City <span class="text-danger">*</span></label> -->
            @if(isset($doctor))
            	<select class="form-control" name="city">
            	<option value="">Select City</option>
            @foreach($city as $c)
            	<option <?php if($doctor[0]['city'] == $c['id']){ ?> selected="selected" <?php } ?> value="{{ $c['id'] }}">{{ $c['city'] }}</option>
            @endforeach
            	</select>
            @else
                <select class="form-control" name="city">
                <option>Select City</option>
            @foreach($city as $c)
                <option <?php if(old('city') == $c['id']){ ?> selected="selected" <?php } ?> value="{{ $c['id'] }}">{{ $c['city'] }}</option>
            @endforeach
                </select>
            @endif
    </div>


    <!-- <div class="col-md-6 mb-3">  
      <input type="text" class="form-control" id="validationDefault02" placeholder="CLINIC" required>
    </div> -->
    
    <!-- <div class="col-md-6 mb-3">
      <div class="input-group">
        <input type="text" class="form-control" id="validationDefaultUsername" placeholder="SPECIALITY" aria-describedby="inputGroupPrepend2" required>
      </div>
    </div> -->

    <div class="form-group">
        <!-- <label class="control-label">Select City <span class="text-danger">*</span></label> -->
            @if(isset($doctor))
            	<select class="form-control" name="name">
            	<option value="">Select Clinic</option>
            @foreach($hospital as $h)
            	<option <?php if($doctor[0]['name'] == $c['id']){ ?> selected="selected" <?php } ?> value="{{ $h['id'] }}">{{ $h['name'] }}</option>
            @endforeach
            	</select>
            @else
                <select class="form-control" name="name">
                <option>Select Clinic</option>
            @foreach($hospital as $h)
                <option <?php if(old('name') == $h['id']){ ?> selected="selected" <?php } ?> value="{{ $h['id'] }}">{{ $h['name'] }}</option>
            @endforeach
                </select>
            @endif
    </div>

    <div class="form-group">
        <!-- <label class="control-label">Select City <span class="text-danger">*</span></label> -->
            @if(isset($doctor))
            	<select class="form-control" name="speciality">
            	<option value="">Select Speciality</option>
            @foreach($speciality as $s)
            	<option <?php if($doctor[0]['speciality'] == $c['id']){ ?> selected="selected" <?php } ?> value="{{ $s['id'] }}">{{ $s['speciality'] }}</option>
            @endforeach
            	</select>
            @else
                <select class="form-control" name="speciality">
                <option>Select Speciality</option>
            @foreach($speciality as $s)
                <option <?php if(old('speciality') == $s['id']){ ?> selected="selected" <?php } ?> value="{{ $s['id'] }}">{{ $s['speciality'] }}</option>
            @endforeach
                </select>
            @endif
    </div>
  
  
    <div class="col-md-6 mb-3">
      <input type="text" class="form-control" id="validationDefault03" name="fname" placeholder="DOCTOR'S NAME" required>
    </div>
    <div class="col-md-6 mb-3">
      <input type="text" class="form-control" id="validationDefault04" name="contact_number" placeholder="PHONE NUMBER" required>
    </div>
    <div class="col-md-6 mb-3">
      <input type="text" class="form-control" id="validationDefault04" name="email" placeholder="EMAIL" required>
    </div>
    <div class="col-md-6 mb-3">
      <input type="text" class="form-control" id="validationDefault04" name="registration_no" placeholder="REGISTRATION NO.(OPTIONAL)">
    </div>
    <div class="col-md-6 mb-3">
      <input type="text" class="form-control" id="validationDefault04" name="registration_council" placeholder="REGISTRATION COUNCIL.(OPTIONAL)">
    </div>
    <div class="col-md-6 mb-3">
      <input type="text" class="form-control" id="validationDefault04" name="aadhaar_no" placeholder="AADHAAR NO.(OPTIONAL)">
    </div>
  </div>


    
    <div class="form-row">
      <div class="form-row">
        <div class="col-md-4 mb-3">
            <button type="reset" class="btn btn-primary btn-info" value="Reset" style="margin-left:10px">RESET</button>
        </div>
      </div>
      <div class="form-row">
        <div class="col-md-4 mb-3">
            <button type="submit" class="btn btn-primary btn-info" value="submit" style="margin-left:10px">CONFIRM</button>
        </div>
      </div>
    </div>
</form>
</div>
</div>

@endsection
