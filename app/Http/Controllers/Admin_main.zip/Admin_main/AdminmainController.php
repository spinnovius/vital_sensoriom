<?php
namespace App\Http\Controllers\Admin_main;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use App\PatientDetail;
use App\User;
use App\City;
use App\Hospital;
use App\Speciality;
use App\Doctor;
use App\DoctorDetail;
use App\Doctorclinic;
/**
 * 
 */
class AdminmainController extends Controller
{
    
    public function dashboard(Request $request) {
        
        return view('admin_main/dashboard_main');
    }

    public function profile(Request $request) {
        
        return view('admin_main/profile');
    }

    public function upcoming(Request $request) {
        
        return view('admin_main/upcoming');
    }

    public function addpatient(Request $request){

    	return view('admin_main/add_patient');
    }

    public function allpatient(Request $request){

       $patient_detail =PatientDetail::
                select('patient_detail.id','users.fname','patient_detail.dob','patient_detail.gender', 'users.contact_number','users.email')
                ->join('users', 'patient_detail.patient_id', '=', 'users.id')
                ->get();
            return  view('admin_main/all_patient',['PatientDetail'=>$patient_detail]);
        
    }

    public function add_doctor(Request $request){
        $city = City::get()->toArray();
        $hospital = Hospital::get()->toArray();
        $speciality = Speciality::get()->toArray();
        //dd($speciality);
        return view('admin_main/add_doctor',['city' => $city,'hospital' => $hospital,'speciality' => $speciality]);
    }

    public function all_doctor(Request $request){

        
        return view('admin_main/all_doctor');
    }


    public function storedoctor(Request $request) {
        //dd("fkjbdgb");
        $messages = [
            'required' => ':attribute is required.',
            'city.required' => 'City is required',
            'name.required' => 'Hospital name is required.',
            'speciality.required' => 'Speciality is required.',
            'fname.required' => 'Doctorname is required',
            'contact_number.required' => 'Phonenumber is required',
            'email.required' => 'email is required',
         ];
        $validator = Validator::make($request->all(), [
                    'city' => 'required',
                    'name' => 'required',
                    'speciality' => 'required',
                    'fname' => 'required',
                    'contact_number' => 'required',
                    'email' => 'required',
                        ], $messages);

        $errors = $validator->errors();
        if ($validator->fails()) {
            return redirect()->back()
                            ->withInput($request->all())
                            ->withErrors($errors);
            exit;
        }


        $doctor = new Doctor;

        $doctor->fname = $request->fname;
        $doctor->contact_number = $request->contact_number;
        $doctor->email = $request->email;
        $doctor->password = app('hash')->make($request->contact_number);
        $doctor->role_id = 2;
        $doctor->verified= 1;
        $doctor->status= 1;
        $doctor->view= 0;
        $doctor->save();
        // dd($doctor->id);

        $doctorclinic = new Doctorclinic;
        $doctorclinic->user_id = $doctor->id;
        $doctorclinic->clinic_id = $request->clinic_id;
        $doctorclinic->save();

        $doctordetail = new DoctorDetail;
        //dd($doctordetail);
        $doctordetail->doctor_id = $doctor->id;
        $doctordetail->speciality = $request->speciality;
        $doctordetail->city = $request->city;
        $doctordetail->fee_of_consultation = 100;
        $doctordetail->mbbs_registration_number = $request->mbbs_registration_number;
        $doctordetail->mbbs_authority_council_name = $request->mbbs_authority_council_name;
        $doctordetail->md_ms_dnb_registration_number = $request->md_ms_dnb_registration_number;
        $doctordetail->md_ms_dnb_counsil_name = $request->md_ms_dnb_counsil_name;
        $doctordetail->dm_mch_dnb_registration_number = $request->dm_mch_dnb_registration_number;
        $doctordetail->dm_mch_dnb_authority_council_name = $request->dm_mch_dnb_authority_council_name;
        //$doctordetail->profile_pic = $request->profile_pic;
        //$doctordetail->document = $request->document;
        $doctordetail->available = $request->available;

        $doctordetail->save();

        /*$doctor = new Doctor;

        $doctor->city = $request->city;
        $doctor->name = $request->name;
        $doctor->speciality = $request->speciality;
        $doctor->fname = $request->fname;
        $doctor->contact_number = $request->contact_number;
        $doctor->email = $request->email;
        $doctor->registration_no = $request->registration_no;
        $doctor->registration_council = $request->registration_council;
        $doctor->aadhaar_no = $request->aadhaar_no;*/
        //dd($doctor);
        //$doctor->save();

        return redirect()->route('admin_main.add_doctor')->with('success','Doctor added successfully.');

    }
}