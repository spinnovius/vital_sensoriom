@extends('layouts.admin_main')
@section('content')

<section class="content-header">
    <h3 style="margin-left: 22px;">ADD NEW PATIENT</h3>
    <!--  <input type="text" placeholder="Search.." name="search">
     <button type="submit"><i class="fa fa-search"></i></button> -->
</section>
<div class="col-sm-10">
<div class="container">
<form>
  <img style="float: right; margin: 0px 0px 15px 15px;" src="image/your-image.png" width="100" />
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <input type="text" class="form-control" id="validationDefault01" placeholder="NAME"  required>
    </div>
    <div class="col-md-4 mb-3">  
      <input type="text" class="form-control" id="validationDefault02" placeholder="AGE" required>
    </div>
    <div class="col-md-4 mb-3">
      <div class="input-group">
        <input type="text" class="form-control" id="validationDefaultUsername" placeholder="SEX" aria-describedby="inputGroupPrepend2" required>
      </div>
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-6 mb-3">
      <input type="text" class="form-control" id="validationDefault03" placeholder="PHONE NUMBER" required>
    </div>
    <div class="col-md-6 mb-3">
      <input type="text" class="form-control" id="validationDefault04" placeholder="EMAIL" required>
    </div>
  </div>


    <section class="content-header">
      <h3>APPOINTMENT DETAILS</h3>
    </section>

    <div class="form-row">
    <div class="col-md-4 mb-3">
      <input type="text" class="form-control" id="validationDefault01" placeholder="CITY" required>
    </div>
    <div class="col-md-4 mb-3">  
      <input type="text" class="form-control" id="validationDefault02" placeholder="HOSPITAL" required>
    </div>
    <div class="col-md-4 mb-3">
      <div class="input-group">
        <input type="text" class="form-control" id="validationDefaultUsername" placeholder="SPECIALITY" aria-describedby="inputGroupPrepend2" required>
      </div>
    </div>
  </div>

  <div class="form-row">
    <div class="col-md-4 mb-3">
      <input type="text" class="form-control" id="validationDefault01" placeholder="DOCTOR'S NAME"  required>
    </div>
    <div class="col-md-4 mb-3">  
      <input type="text" class="form-control" id="validationDefault02" placeholder="DATE"  required>
    </div>
    <div class="col-md-4 mb-3">
      <div class="input-group">
        <input type="text" class="form-control" id="validationDefaultUsername" placeholder="TIME" aria-describedby="inputGroupPrepend2" required>
      </div>
    </div>
  </div>
   <div class="form-row">
    <div class="col-md-6 mb-3">
      <input type="text" class="form-control" id="validationDefault03" placeholder="AADHAAR NO.(OPTIONAL)">
    </div>
    <div class="form-row">
      <div class="form-row">
        <div class="col-md-4 mb-3">
            <button type="reset" class="btn btn-primary btn-info" value="Reset" style="margin-left:10px">RESET</button>
        </div>
      </div>
      <div class="form-row">
        <div class="col-md-4 mb-3">
            <button type="submit" class="btn btn-primary btn-info" value="submit" style="margin-left:10px">CONFIRM</button>
        </div>
      </div>
    </div>
</form>
</div>
</div>

@endsection
